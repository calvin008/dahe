import instance from './request'

export const Login = (res) =>{
    return instance({
        url:'/login',
        method: 'POST',
        data:res

    }).then(response =>{
        console.log(response.data)
        if (response.data.success) { 

        } else {

        }
    })
} 

export default {Login}