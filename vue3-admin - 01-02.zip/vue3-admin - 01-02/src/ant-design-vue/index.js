import { Form, Input, Button } from 'ant-design-vue';
import 'ant-design-vue/dist/antd.css';

const components= [
    Form,
    Input,
    Button
]
export function setupAntd(app) {
    components.forEach(component => {
        app.use(component)
      })
  }