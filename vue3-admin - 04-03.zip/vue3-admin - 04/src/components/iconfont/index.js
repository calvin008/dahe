import { createFromIconfontCN } from '@ant-design/icons-vue';

export const IconFont = createFromIconfontCN({
  scriptUrl: '//at.alicdn.com/t/font_1617479_lw8fprdjcs.js',
});

