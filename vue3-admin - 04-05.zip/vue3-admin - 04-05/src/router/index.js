import {createRouter, createWebHashHistory} from 'vue-router'

export const constantRoutes = [
  {
    path: '/login',
    component: () => import('@/views/login/Login.vue'),
    hidden: true,
  },
  {
    path: '/403',
    name: '403',
    component: () => import('@/views/error/403.vue'),
    hidden: true,
  },
  {
    path: '/404',
    name: '404',
    component: () => import('@/views/error/404.vue'),
    hidden: true,
  },
]



const router = createRouter({
  history: createWebHashHistory(),
  routes: constantRoutes,
})

export default router