<!--  -->
<template>
  <div>
    <a-menu theme="dark" mode="inline" v-model:selectedKeys="selectedKeys">
      <a-menu-item key="1">
        <icon-font type="icon-voice-fill" />
        <span>nav 1</span>
      </a-menu-item>
      <a-menu-item key="2">
        <icon-font type="icon-voice-fill" />
        <span>nav 2</span>
      </a-menu-item>
      <a-menu-item key="3">
        <icon-font type="icon-voice-fill" />
        <span>nav 3</span>
      </a-menu-item>
    </a-menu>
  </div>
</template>

<script>
import { IconFont } from "@/components/iconfont";

export default {
  props: {
    collapsed: {
      // 侧边栏菜单是否收起
      type: Boolean,
    },
  },
  components: {
    IconFont,
  },
};
</script>
<style lang='scss' scoped>
</style>